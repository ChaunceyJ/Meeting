package com.tongji.meeting.model;

public class Calendar {
    private int calendarId;
    private String calendarName;

    public void setCalendarId(int calendarId) {
        this.calendarId = calendarId;
    }

    public void setCalendarName(String calendarName) {
        this.calendarName = calendarName;
    }

    public int getCalendarId() {
        return calendarId;
    }

    public String getCalendarName() {
        return calendarName;
    }
}
