package com.tongji.meeting.dao;

public interface BaseDao {
}
