package com.tongji.meeting.service;

public interface ICalendar {
}
