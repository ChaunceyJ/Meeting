package com.tongji.meeting.util;

public class GlobalValues {

//    public static String appId = "wxedf8598dfdc01036";

//    public static String appSecret = "153cd27786239b16e384b40c970c208e";

    public static String appId = "wx89da1aa7c73b464a";

    public static String appSecret = "4fd3195a447f23519483f4d6302d5354";

    public static long mySessionTime = 2*24*60*60;
}
